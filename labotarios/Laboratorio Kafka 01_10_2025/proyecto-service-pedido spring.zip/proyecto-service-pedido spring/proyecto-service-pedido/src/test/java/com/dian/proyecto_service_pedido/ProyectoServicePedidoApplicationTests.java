package com.dian.proyecto_service_pedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoServicePedidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
