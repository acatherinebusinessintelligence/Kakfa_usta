package com.dian.proyecto_service_pedido.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dian.proyecto_service_pedido.dto.RequestPedido;
import com.dian.proyecto_service_pedido.model.Pedido;

@Service
public class PedidoService {

    @Autowired
    private KafkaProducerService kafkaProducerService;

    public void registrarPedido(RequestPedido pedido){
        Pedido pedidoEnviarAlTopic = new Pedido();
        pedidoEnviarAlTopic.setId(pedido.getId());
        pedidoEnviarAlTopic.setProducto(pedido.getProducto());
        pedidoEnviarAlTopic.setCantidad(pedido.getCantidad());
        pedidoEnviarAlTopic.setPrecio(pedido.getPrecio());
        pedidoEnviarAlTopic.setUsuario(pedido.getUsuario());

        this.kafkaProducerService.enviarPedido(pedidoEnviarAlTopic);
    }

}
