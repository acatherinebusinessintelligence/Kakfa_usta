package com.dian.proyecto_service_pedido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoServicePedidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoServicePedidoApplication.class, args);
	}

}
