package com.dian.proyecto_service_pedido.model;

import lombok.Data;

@Data
public class Pedido {
    private int id;
    private String producto;
    private int cantidad;
    private float precio;
    private Usuario usuario;
}
