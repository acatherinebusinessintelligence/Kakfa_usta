package com.dian.proyecto_service_pedido.services;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.dian.proyecto_service_pedido.model.Pedido;

@Service
public class KafkaConsumerService {
    @KafkaListener(topics = "pedidos", groupId = "grupo-factura", containerFactory = "kafkaListenerContainerFactory")
    public void consumir(Pedido pedido) {
        System.out.println("📥 Consumidor recibió Pedido: " + pedido);
        System.out.println("=====================================");
        System.out.println("              FACTURA");
        System.out.println("=====================================");
        System.out.println("ID Pedido: " + pedido.getId());
        System.out.println(
                "Nombre Cliente: " + pedido.getUsuario().getNombre() + " " + pedido.getUsuario().getApellido());
        System.out.println("Documento: " + pedido.getUsuario().getTipoDocumento() + " "
                + pedido.getUsuario().getNumeroDocumento());
        System.out.println("Correo: " + pedido.getUsuario().getCorreo());
        System.out.println("Producto: " + pedido.getProducto());
        System.out.println("Cantidad: " + pedido.getCantidad());
        System.out.println("Precio Unitario: " + pedido.getPrecio());
        System.out.println("Total: " + (pedido.getCantidad() * pedido.getPrecio()));
        System.out.println("=====================================");
        System.out.println("Gracias por su compra!");
        System.out.println("=====================================");
    }

}
