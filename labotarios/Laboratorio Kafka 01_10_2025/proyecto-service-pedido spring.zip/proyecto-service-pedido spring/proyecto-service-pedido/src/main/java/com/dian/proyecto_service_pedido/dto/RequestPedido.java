package com.dian.proyecto_service_pedido.dto;

import com.dian.proyecto_service_pedido.model.Usuario;

import lombok.Data;

@Data
public class RequestPedido {
    private int id;
    private String producto;
    private int cantidad;
    private float precio;
    private Usuario usuario;
}
