# pip install fastapi uvicorn confluent-kafka pydantic
from fastapi import FastAPI

from app.controller.index_controller import router
from app.services.consumer_service import start_consumer

app = FastAPI(title="Aplicación Notificaciones")

app.include_router(router=router)

@app.on_event("startup")
def start():
    start_consumer()