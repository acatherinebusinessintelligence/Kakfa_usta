from fastapi import APIRouter
from starlette.routing import Router

router = APIRouter(
    prefix="/server"
)

@router.get("/ping")
def index():
    return "Servicio Arriba"