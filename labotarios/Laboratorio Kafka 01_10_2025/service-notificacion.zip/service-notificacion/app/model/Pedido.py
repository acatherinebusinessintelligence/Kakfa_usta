from pydantic import BaseModel


class Usuario(BaseModel):
    nombre:str
    apellido:str
    tipoDocumento:str
    numeroDocumento:str
    correo:str

class Pedido(BaseModel):
    id:int
    producto:str
    cantidad:int
    precio:float
    usuario: Usuario