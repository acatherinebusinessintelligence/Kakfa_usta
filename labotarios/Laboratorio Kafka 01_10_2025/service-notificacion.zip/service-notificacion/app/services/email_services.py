import emails
import os
from jinja2 import Environment, FileSystemLoader
from dotenv import load_dotenv

from app.model.Pedido import Pedido

# Cargar variables de entorno
load_dotenv()

# Ruta base (ajústala según tu estructura)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_FOLDER = os.path.abspath(os.path.join(BASE_DIR, "../email", "templates"))

# Imprimir la ruta para verificar
print(f"Ruta de plantillas: {TEMPLATE_FOLDER}")
# Configurar Jinja2
env = Environment(loader=FileSystemLoader(TEMPLATE_FOLDER))

def load_template(template_name: str, context: dict) -> str:
    """Carga y renderiza una plantilla HTML con contexto"""
    try:
        template = env.get_template(template_name)
        return template.render(**context)
    except Exception as e:
        raise RuntimeError(f"Error cargando plantilla '{template_name}': {str(e)}")

def send_email(
    to_email: str,
    subject: str,
    template_name: str,
    context: Pedido,
    from_name: str = "SnapOrder",
    from_email: str = "snaporderapp@outlook.com"
) -> bool:
    """Envía un correo con HTML renderizado desde plantilla"""
    try:
        print("🔧 Iniciando envío de correo...")
        print("➡️  Destinatario:", to_email)
        print("➡️  Asunto:", subject)
        print("➡️  Plantilla usada:", template_name)
        print("➡️  Contexto recibido:", context)
        context_dict = {
            'id': context.id,
            'producto': context.producto,
            'cantidad': context.cantidad,
            'precio': context.precio,
            'usuario_nombre': context.usuario.nombre,
            'usuario_apellido': context.usuario.apellido,
            'usuario_correo': context.usuario.correo,
        }
        html_content = load_template(template_name, context_dict)
        print("✅ Plantilla renderizada correctamente.")
        print("📄 Contenido HTML generado:")
        print(html_content)

        final_from_email = from_email or os.getenv("MAIL_FROM")
        if not final_from_email:
            raise ValueError("❌ 'from_email' no está definido y no se encontró 'MAIL_FROM' en variables de entorno.")

        print("📨 Remitente:", (from_name, final_from_email))

        smtp_config = {
            "host": "sandbox.smtp.mailtrap.io",
            "port": 587,
            "tls": True,
            "user": "9fb951684c85c4",
            "password": "8504cba1f6740b",
        }

        print("📡 Configuración SMTP:")
        for k, v in smtp_config.items():
            # Oculta la contraseña
            display_value = "***" if "pass" in k.lower() else v
            print(f"  - {k}: {display_value}")

        message = emails.html(
            subject=subject,
            html=html_content,
            mail_from=(from_name, final_from_email),
        )

        response = message.send(
            to=to_email,
            smtp=smtp_config,
        )
        print(response)
        print(f"✅ Correo enviado a {to_email}: {response.status_code == 250}")
        return response.status_code == 250

    except Exception as e:
        print(f"❌ Error enviando email a {to_email}: {e}")
        return False

