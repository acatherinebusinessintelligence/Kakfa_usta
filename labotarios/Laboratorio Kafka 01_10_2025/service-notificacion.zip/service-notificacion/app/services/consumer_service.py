import json, threading
from confluent_kafka import Consumer

from app.model.Pedido import Pedido
from app.services.email_services import send_email

kafka_config = {
    "bootstrap.servers":"localhost:9092",
    "group.id":"grupo-notificacion",
    "auto.offset.reset":"earliest"
}

consumer = Consumer(kafka_config)

def consume_loop():
    consumer.subscribe(["pedidos"])

    while True:
        msg = consumer.poll(1.0)
        if msg is None:
            continue
        if msg.error():
            print("error")
            continue
        try:
            data= json.loads(msg.value().decode("utf-8"))
            pedido = Pedido(**data)
            print(f"Pedido {pedido.usuario} ")
            # Notificación Correo
            send_email(pedido.usuario.correo,"Notificación Pedido","template_pedido.html", context=pedido)
        except Exception as e:
            print(e)

def start_consumer():
    thread = threading.Thread(target=consume_loop, daemon=True)
    thread.start()
