package com.dian.proyecto_service_pedido.model;

import lombok.Data;

@Data
public class Usuario {
    private String nombre;
    private String apellido;
    private String tipoDocumento;
    private String numeroDocumento;
    private String correo;
}
