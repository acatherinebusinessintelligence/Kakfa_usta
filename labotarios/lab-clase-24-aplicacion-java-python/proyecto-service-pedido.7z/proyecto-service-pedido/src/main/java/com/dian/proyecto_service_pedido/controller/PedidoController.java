package com.dian.proyecto_service_pedido.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dian.proyecto_service_pedido.dto.RequestPedido;
import com.dian.proyecto_service_pedido.services.PedidoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;
    @PostMapping("/registrar")
    public void registrarPedido(@RequestBody RequestPedido pedido) {
        try {
           this.pedidoService.registrarPedido(pedido);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
}
